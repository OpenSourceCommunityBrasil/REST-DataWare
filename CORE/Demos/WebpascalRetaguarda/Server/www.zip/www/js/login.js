function isEmptyObject(obj) {
    return JSON.stringify(obj) === '{}';
}

function Validcnpj(cnpj) {
    str = $("#cnpj").val().replace(/[^\d]+/g, '');

    $.ajax({
        url: '/login?cnpj=' + str,
        type: 'GET',
        dataType: 'json',
        contentType: "application/json; charset=utf-8",
        success: function(res) {

            if (res.length == 0) {
                document.getElementById("nomeempresa").innerHTML = 'Empresa não registrada na base de dados';
                $('#nomeempresa').removeClass("bg-info");
                $('#nomeempresa').addClass("bg-danger");
            } else {
                document.getElementById("nomeempresa").innerHTML = res[0].nome;
                $('#nomeempresa').removeClass("bg-danger");

            }
        }
    });

}