# Delphi Mocks

Delphi Mocks is a simple mocking framework for Delphi XE2 or later. It makes use of RTTI features that are only available in Delphi XE2, however I do hope to be able to get it working with earlier versions of Delphi (2010 or later) at some stage.

UPDATED : Now implements mocking on classes and interfaces. 

TODO : More testing.